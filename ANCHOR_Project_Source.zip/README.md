# ANCHOR — native iPhone DBT companion

This repository contains a native SwiftUI iPhone app and a real WidgetKit extension. It is an early personal-use build, not a clinically validated product and not yet ready for public App Store release.

## What's included

- SwiftUI app with Home, emotion-to-skill finder, DBT skills library, crisis support, daily care and personal toolkit.
- Four feelings/emotional support routes, intensity-aware recommendations and DBT modules.
- A crisis route led by: **“Our goal right now is to stop things from getting worse.”**
- Four separately selectable WidgetKit Home Screen widgets (Crisis, Feelings, Daily Check-in, Daily Care), each supporting iPhone small, medium and large sizes.
- One-tap widget links into Crisis, Feelings and Daily Care; interactive daily-care check-off buttons.
- App Group storage shared between the app and widgets (`group.com.anchor.dbt.shared`).
- Deep links (`anchor://crisis`, `anchor://feelings`, `anchor://dailycare`).
- Codemagic workflow for a cloud macOS build and TestFlight upload.

## Important status and limitations

This source has not yet been compiled on Apple's Xcode toolchain or tested on a physical iPhone. A signed installable app cannot be produced from this environment. The cloud build is the next engineering step.

The Daily Care screen includes a user-selected repeating daily medication reminder using iOS local notifications. It requests permission and can be turned off from the same screen. Not yet implemented: daily rollover/history, a full safety-plan editor, clinical review, privacy policy, App Store metadata/screenshots, accessibility QA and release testing. The medication section is a manual check-in only; it does not advise on doses. Widget refresh timing is controlled by iOS and is not guaranteed to be instantaneous.

The app stores personal entries on-device using UserDefaults/App Group storage. It does not currently sync to a server. Do not enter information you would not want stored on the device. This app is educational support, not treatment or emergency care.

## Cloud build route (no personal Mac required)

The project is configured for Codemagic. For the iPhone-only upload route, place `ANCHOR_Project_Source.zip` and the standalone root `codemagic.yaml` in a new private GitHub repository. First run `ANCHOR iOS (compile check — no Apple signing)` to compile the app and widgets in the cloud without an Apple Developer membership. Only after that succeeds should you set up Apple signing and run the TestFlight workflow. You will need:

1. A personal GitHub account/repository containing these project files (do not use a work account or work device).
2. An Apple Developer Program membership and App Store Connect access only for the signed TestFlight workflow. The compile-check workflow does not need Apple signing.
3. A Codemagic account connected to the personal GitHub repository.
4. In Codemagic, connect an App Store Connect API key and name that integration exactly `ANCHOR_APP_STORE_CONNECT` (or change the name in `codemagic.yaml`). Create a dedicated API key; do not share your Apple ID password.
5. Register the App Group `group.com.anchor.dbt.shared` for both bundle identifiers `com.anchor.dbt` and `com.anchor.dbt.widgets`. The App Group capability must be available to both app and widget extension provisioning profiles.
6. Create a TestFlight group named `ANCHOR Personal Testing` or remove the `beta_groups` section until one exists.
7. Start the `ANCHOR iOS (compile check — no Apple signing)` workflow first. If it succeeds, configure Apple signing and then start `ANCHOR iOS (signed TestFlight build)`. If Codemagic reports signing/profile errors, stop and fix those before attempting installation.

Codemagic's current native iOS signing and TestFlight instructions:
- https://docs.codemagic.io/yaml-code-signing/signing-ios/
- https://docs.codemagic.io/yaml-publishing/app-store-connect/

## Project structure

- `AnchorDBT.xcodeproj` — native Xcode project with app and widget extension targets.
- `AnchorApp/` — SwiftUI app source, app Info.plist and App Group entitlements.
- `AnchorWidgets/` — WidgetKit extension source, Info.plist and App Group entitlements.
- `codemagic.yaml` — cloud build and TestFlight workflow.

## Bundle identifiers

- App: `com.anchor.dbt`
- Widget extension: `com.anchor.dbt.widgets`
- App Group: `group.com.anchor.dbt.shared`

These identifiers are defaults for this project. If you change them, update the project build settings, entitlements, `AnchorStore.swift`, `AnchorWidgets.swift`, and the Codemagic workflow consistently.
