import WidgetKit
import SwiftUI
import AppIntents

private let shared = UserDefaults(suiteName: "group.com.anchor.dbt.shared") ?? .standard

struct AnchorEntry: TimelineEntry {
    let date: Date
    let medicationTaken: Bool
    let waterDone: Bool
    let foodDone: Bool
    let skillDone: Bool
    let selfCareDone: Bool
}

struct AnchorProvider: TimelineProvider {
    func placeholder(in context: Context) -> AnchorEntry { sample }
    func getSnapshot(in context: Context, completion: @escaping (AnchorEntry) -> Void) { completion(makeEntry()) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<AnchorEntry>) -> Void) {
        completion(Timeline(entries: [makeEntry()], policy: .after(Date().addingTimeInterval(900))))
    }
    private func makeEntry() -> AnchorEntry {
        AnchorEntry(date: .now,
            medicationTaken: shared.bool(forKey: "medicationTaken"),
            waterDone: shared.bool(forKey: "waterDone"),
            foodDone: shared.bool(forKey: "foodDone"),
            skillDone: shared.bool(forKey: "skillDone"),
            selfCareDone: shared.bool(forKey: "selfCareDone"))
    }
    private var sample: AnchorEntry { AnchorEntry(date: .now, medicationTaken: false, waterDone: false, foodDone: false, skillDone: false, selfCareDone: false) }
}

struct MarkCareIntent: AppIntent {
    static var title: LocalizedStringResource = "Mark daily care item"
    @Parameter(title: "Item key") var item: String
    init() { item = "waterDone" }
    init(item: String) { self.item = item }
    func perform() async throws -> some IntentResult {
        let allowed = ["waterDone", "foodDone", "skillDone", "selfCareDone", "medicationTaken"]
        guard allowed.contains(item) else { return .result() }
        shared.set(true, forKey: item)
        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}

private enum WidgetStyle {
    static let lavender = Color(red: 0.55, green: 0.48, blue: 0.68)
    static let sage = Color(red: 0.72, green: 0.79, blue: 0.72)
    static let blush = Color(red: 0.91, green: 0.82, blue: 0.87)
    static let cream = Color(red: 0.98, green: 0.96, blue: 0.92)
    static let ink = Color(red: 0.30, green: 0.27, blue: 0.35)
}

private struct CrisisWidgetView: View {
    @Environment(\.widgetFamily) private var family
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("ANCHOR • PAUSE").font(.caption.bold()).tracking(1)
            Text("Our goal right now is to stop things from getting worse.")
                .font(family == .systemSmall ? .subheadline.weight(.semibold) : .headline)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 2)
            Link(destination: URL(string: "anchor://crisis")!) {
                Label("Open crisis support", systemImage: "heart.fill").font(.caption.bold())
            }
        }
        .foregroundStyle(WidgetStyle.ink).padding()
        .containerBackground(WidgetStyle.blush, for: .widget)
    }
}

private struct FeelingsWidgetView: View {
    @Environment(\.widgetFamily) private var family
    var body: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 8) {
                Text("HOW AM I FEELING?").font(.caption.bold()).tracking(0.6)
                Text("Name the feeling. Find a skill.").font(family == .systemSmall ? .caption : .subheadline)
                Spacer(minLength: 0)
                Link("Choose an emotion →", destination: URL(string: "anchor://feelings")!).font(.caption.bold())
            }
            Spacer(minLength: 0)
            Image(systemName: "heart.text.square.fill").font(.system(size: family == .systemSmall ? 30 : 42)).foregroundStyle(WidgetStyle.lavender)
        }
        .foregroundStyle(WidgetStyle.ink).padding()
        .containerBackground(WidgetStyle.cream, for: .widget)
    }
}

private struct CheckInWidgetView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("A GENTLE CHECK-IN").font(.caption.bold()).tracking(0.6)
            Text("What do I need in this moment?").font(.headline)
            Text("No judgement. No pressure. Just notice.").font(.caption).foregroundStyle(.secondary)
            Spacer(minLength: 0)
            Link("Check in with myself →", destination: URL(string: "anchor://dailycare")!).font(.caption.bold())
        }
        .foregroundStyle(WidgetStyle.ink).padding()
        .containerBackground(WidgetStyle.sage.opacity(0.55), for: .widget)
    }
}

private struct DailyCareWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: AnchorEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("DAILY CARE").font(.caption.bold()).tracking(0.8)
            Text("Little things count.").font(.headline)
            careRow("Medication", done: entry.medicationTaken, key: "medicationTaken")
            careRow("Water", done: entry.waterDone, key: "waterDone")
            careRow("Food", done: entry.foodDone, key: "foodDone")
            careRow("DBT skill", done: entry.skillDone, key: "skillDone")
            careRow("Kindness to me", done: entry.selfCareDone, key: "selfCareDone")
            if family != .systemSmall {
                Link("Open ANCHOR →", destination: URL(string: "anchor://dailycare")!).font(.caption.bold()).padding(.top, 2)
            }
        }
        .foregroundStyle(WidgetStyle.ink).padding()
        .containerBackground(WidgetStyle.cream, for: .widget)
    }
    @ViewBuilder private func careRow(_ title: String, done: Bool, key: String) -> some View {
        HStack(spacing: 7) {
            Image(systemName: done ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(done ? .green : WidgetStyle.lavender)
            Text(title).font(.caption)
            Spacer(minLength: 0)
            if !done {
                Button(intent: MarkCareIntent(item: key)) { Image(systemName: "plus.circle.fill") }
                    .buttonStyle(.plain).tint(WidgetStyle.lavender)
            }
        }
    }
}

struct AnchorCrisisWidget: Widget {
    let kind = "AnchorCrisisWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AnchorProvider()) { _ in CrisisWidgetView() }
            .configurationDisplayName("ANCHOR • Crisis support")
            .description("A one-tap reminder to pause and reach your crisis plan.")
            .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

struct AnchorFeelingsWidget: Widget {
    let kind = "AnchorFeelingsWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AnchorProvider()) { _ in FeelingsWidgetView() }
            .configurationDisplayName("ANCHOR • How am I feeling?")
            .description("Choose an emotion and get a DBT skill suggestion.")
            .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

struct AnchorCheckInWidget: Widget {
    let kind = "AnchorCheckInWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AnchorProvider()) { _ in CheckInWidgetView() }
            .configurationDisplayName("ANCHOR • Daily check-in")
            .description("A gentle prompt to check in with yourself.")
            .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

struct AnchorDailyCareWidget: Widget {
    let kind = "AnchorDailyCareWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AnchorProvider()) { entry in DailyCareWidgetView(entry: entry) }
            .configurationDisplayName("ANCHOR • Daily care")
            .description("Tick off small acts of daily care from your Home Screen.")
            .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

@main
struct AnchorWidgets: WidgetBundle {
    var body: some Widget {
        AnchorCrisisWidget()
        AnchorFeelingsWidget()
        AnchorCheckInWidget()
        AnchorDailyCareWidget()
    }
}
