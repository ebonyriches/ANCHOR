import Foundation

import SwiftUI

enum AnchorTheme {
    static let lavender = Color(red: 0.55, green: 0.48, blue: 0.68)
    static let sage = Color(red: 0.72, green: 0.79, blue: 0.72)
    static let blush = Color(red: 0.91, green: 0.82, blue: 0.87)
    static let cream = Color(red: 0.98, green: 0.96, blue: 0.92)
}

struct SkillRecommendation: Identifiable {
    let id = UUID()
    let title: String
    let reason: String
    let steps: [String]
}

struct Feeling: Identifiable {
    let id: String
    let label: String
    let symbol: String
}

enum AnchorData {
    static let feelings: [Feeling] = [
        .init(id: "anxious", label: "Anxious", symbol: "😰"),
        .init(id: "angry", label: "Angry", symbol: "😡"),
        .init(id: "overwhelmed", label: "Overwhelmed", symbol: "😵‍💫"),
        .init(id: "rejected", label: "Rejected", symbol: "💔"),
        .init(id: "abandoned", label: "Afraid of abandonment", symbol: "🫂"),
        .init(id: "ashamed", label: "Ashamed", symbol: "🫣"),
        .init(id: "sad", label: "Sad", symbol: "🌧️"),
        .init(id: "numb", label: "Numb or disconnected", symbol: "🫥"),
        .init(id: "impulsive", label: "Strong urge to act", symbol: "⚡"),
        .init(id: "jealous", label: "Jealous", symbol: "🫤"),
        .init(id: "lonely", label: "Lonely", symbol: "🩵"),
        .init(id: "guilty", label: "Guilty", symbol: "🥺")
    ]

    static func recommendation(for feeling: String, intensity: Int) -> SkillRecommendation {
        let highDistress = intensity >= 8
        switch feeling {
        case "anxious":
            return .init(title: highDistress ? "TIPP and paced breathing" : "Paced breathing and grounding",
                         reason: "Help your nervous system settle before trying to solve the problem.",
                         steps: ["Put both feet on the floor and look around the room.",
                                 "Breathe in gently, then make your exhale a little longer.",
                                 "If helpful and medically safe for you, try a cool cloth on your face. Avoid extreme cold.",
                                 "When the intensity eases, identify one manageable next step."])
        case "angry":
            return .init(title: "STOP",
                         reason: "Create space between the emotion and the action.",
                         steps: ["Stop. Don't act on the first urge.",
                                 "Take a step back, physically or mentally.",
                                 "Observe your body, thoughts and urges without judging them.",
                                 "Proceed mindfully: choose what helps your longer-term goals."])
        case "overwhelmed":
            return .init(title: highDistress ? "TIPP, then one small step" : "Grounding and one-mindfulness",
                         reason: "Lower the intensity before taking on the whole situation.",
                         steps: ["Pause and remind yourself: “I only need to handle this moment.”",
                                 "Name five things you can see and feel your feet on the floor.",
                                 "Slow your breathing, especially the exhale.",
                                 "Choose just one small next step—or pause if no action is needed."])
        case "rejected", "abandoned":
            return .init(title: "Self-validation and Check the Facts",
                         reason: "The hurt is real, but the feeling alone cannot tell you what another person thinks.",
                         steps: ["Name the feeling: “I'm feeling rejected and this hurts.”",
                                 "Separate what you know from what you fear might be true.",
                                 "Offer yourself the validation you would offer someone you care about.",
                                 "Wait until you're steadier before sending a message or making a big decision."])
        case "ashamed":
            return .init(title: "Self-validation and Check the Facts",
                         reason: "You can take responsibility for an action without deciding you are a bad person.",
                         steps: ["Notice and name the shame without attacking yourself.",
                                 "Separate what happened from your identity.",
                                 "Ask whether repair or an apology is actually needed.",
                                 "Choose one compassionate, values-based next step."])
        case "sad", "lonely":
            return .init(title: "Self-soothing and Opposite Action",
                         reason: "Respond gently to the sadness and consider one small action that supports connection.",
                         steps: ["Acknowledge: “This is sadness/loneliness, and it matters.”",
                                 "Use one of your five senses to soothe yourself.",
                                 "If it fits the facts, take one small step towards connection or a meaningful activity.",
                                 "Keep the step small; you don't have to force yourself to feel better."])
        case "numb":
            return .init(title: "Mindfulness and sensory grounding",
                         reason: "Gently reconnect with the present without forcing an emotion.",
                         steps: ["Press your feet into the floor.",
                                 "Hold a familiar object and describe its texture.",
                                 "Name where you are, the day, and three things you can see.",
                                 "Choose a comforting, low-pressure activity."])
        case "impulsive":
            return .init(title: "STOP and Pros & Cons",
                         reason: "An urge is an experience, not an instruction. Give yourself time before acting.",
                         steps: ["Stop and create a little distance from the action.",
                                 "Name the urge and rate its intensity from 1 to 10.",
                                 "Consider short- and long-term pros and cons of acting versus not acting.",
                                 "Delay the decision for ten minutes, then reassess with a trusted support if useful."])
        case "jealous":
            return .init(title: "Check the Facts",
                         reason: "Explore what the jealousy is telling you before reacting.",
                         steps: ["Name the fear or need underneath the jealousy.",
                                 "Write down observable facts separately from assumptions.",
                                 "Consider what you need and what you can ask for respectfully.",
                                 "Avoid checking, accusing or making a big decision while highly activated."])
        case "guilty":
            return .init(title: "Check the Facts and repair",
                         reason: "Guilt can guide repair when it fits the facts; misplaced guilt needs self-validation.",
                         steps: ["Ask whether you acted against your values.",
                                 "If so, acknowledge it without attacking yourself.",
                                 "Consider a proportionate repair or apology.",
                                 "If the guilt doesn't fit the facts, practise self-validation."])
        default:
            return .init(title: "Mindfulness and Check the Facts",
                         reason: "Start by observing what is happening before choosing a response.",
                         steps: ["Pause and notice your body.",
                                 "Name the closest emotion you can identify.",
                                 "Separate facts from interpretations.",
                                 "Choose one grounding or self-soothing action."])
        }
    }
}
