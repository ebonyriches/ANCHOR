import Foundation
import SwiftUI
import WidgetKit

@MainActor
final class AnchorStore: ObservableObject {
    static let shared = AnchorStore()
    private let defaults = UserDefaults(suiteName: "group.com.anchor.dbt.shared") ?? .standard

    @Published var medicationTaken: Bool { didSet { defaults.set(medicationTaken, forKey: "medicationTaken"); defaults.set(Date().timeIntervalSince1970, forKey: "medicationUpdated"); WidgetCenter.shared.reloadAllTimelines() } }
    @Published var waterDone: Bool { didSet { defaults.set(waterDone, forKey: "waterDone"); WidgetCenter.shared.reloadAllTimelines() } }
    @Published var foodDone: Bool { didSet { defaults.set(foodDone, forKey: "foodDone"); WidgetCenter.shared.reloadAllTimelines() } }
    @Published var skillDone: Bool { didSet { defaults.set(skillDone, forKey: "skillDone"); WidgetCenter.shared.reloadAllTimelines() } }
    @Published var selfCareDone: Bool { didSet { defaults.set(selfCareDone, forKey: "selfCareDone"); WidgetCenter.shared.reloadAllTimelines() } }
    @Published var medicationName: String { didSet { defaults.set(medicationName, forKey: "medicationName") } }
    @Published var medicationTime: String { didSet { defaults.set(medicationTime, forKey: "medicationTime") } }
    @Published var trustedContactName: String { didSet { defaults.set(trustedContactName, forKey: "trustedContactName") } }
    @Published var trustedContactPhone: String { didSet { defaults.set(trustedContactPhone, forKey: "trustedContactPhone") } }
    @Published var personalReasons: String { didSet { defaults.set(personalReasons, forKey: "personalReasons") } }
    @Published var triggerNotes: String { didSet { defaults.set(triggerNotes, forKey: "triggerNotes") } }
    @Published var helpfulNotes: String { didSet { defaults.set(helpfulNotes, forKey: "helpfulNotes") } }

    private init() {
        medicationTaken = defaults.bool(forKey: "medicationTaken")
        waterDone = defaults.bool(forKey: "waterDone")
        foodDone = defaults.bool(forKey: "foodDone")
        skillDone = defaults.bool(forKey: "skillDone")
        selfCareDone = defaults.bool(forKey: "selfCareDone")
        medicationName = defaults.string(forKey: "medicationName") ?? ""
        medicationTime = defaults.string(forKey: "medicationTime") ?? "09:00"
        trustedContactName = defaults.string(forKey: "trustedContactName") ?? ""
        trustedContactPhone = defaults.string(forKey: "trustedContactPhone") ?? ""
        personalReasons = defaults.string(forKey: "personalReasons") ?? ""
        triggerNotes = defaults.string(forKey: "triggerNotes") ?? ""
        helpfulNotes = defaults.string(forKey: "helpfulNotes") ?? ""
    }

    func resetDailyCare() {
        medicationTaken = false
        waterDone = false
        foodDone = false
        skillDone = false
        selfCareDone = false
    }
}
