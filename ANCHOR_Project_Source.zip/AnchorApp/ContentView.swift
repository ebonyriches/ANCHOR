import SwiftUI
import UserNotifications

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var showCrisis = false
    @EnvironmentObject private var store: AnchorStore

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView().tabItem { Label("Home", systemImage: "house.fill") }.tag(0)
            FeelingsView().tabItem { Label("Feelings", systemImage: "heart.text.square") }.tag(1)
            SkillsView().tabItem { Label("DBT Skills", systemImage: "leaf") }.tag(2)
            DailyCareView().tabItem { Label("Daily Care", systemImage: "checkmark.circle") }.tag(3)
            ToolkitView().tabItem { Label("My Toolkit", systemImage: "person.crop.circle") }.tag(4)
        }
        .preferredColorScheme(.light)
        .sheet(isPresented: $showCrisis) { NavigationStack { CrisisView() } }
        .onOpenURL { url in
            switch url.host {
            case "crisis": showCrisis = true
            case "feelings": selectedTab = 1
            case "dailycare": selectedTab = 3
            default: break
            }
        }
    }
}

struct SoftCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .padding(16).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(red: 0.97, green: 0.95, blue: 0.98))
            .clipShape(RoundedRectangle(cornerRadius: 20))
    }
}

struct HomeView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("A softer place to land.").font(.title2.bold())
                    Text("You don't have to solve everything right now. Just take the next small step.")
                        .foregroundStyle(.secondary)
                    NavigationLink(destination: CrisisView()) {
                        Label("CRISIS SUPPORT", systemImage: "lifepreserver.fill")
                            .font(.headline).frame(maxWidth: .infinity).padding()
                            .background(Color(red: 0.91, green: 0.82, blue: 0.87))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }.buttonStyle(.plain)
                    NavigationLink(destination: FeelingsView()) {
                        SoftCard { Label("How am I feeling?", systemImage: "heart.fill").font(.headline); Text("Choose an emotion and find a DBT skill.") }
                    }.buttonStyle(.plain)
                    NavigationLink(destination: DailyCareView()) {
                        SoftCard { Label("Daily Care", systemImage: "sun.max.fill").font(.headline); Text("Medication, food, water and small acts of care.") }
                    }.buttonStyle(.plain)
                    NavigationLink(destination: SkillsView()) {
                        SoftCard { Label("DBT Skills Library", systemImage: "leaf.fill").font(.headline); Text("Mindfulness, distress tolerance, emotion regulation and relationships.") }
                    }.buttonStyle(.plain)
                    Text("Pause. Survive. Regulate. Then decide.")
                        .font(.subheadline.weight(.semibold)).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity).padding(.top, 8)
                }.padding()
            }.navigationTitle("ANCHOR")
        }
    }
}

struct FeelingsView: View {
    @State private var selected = "anxious"
    @State private var intensity = 7
    @State private var showResult = false
    private var recommendation: SkillRecommendation { AnchorData.recommendation(for: selected, intensity: intensity) }
    var body: some View {
        NavigationStack {
            Form {
                Section("What are you feeling?") {
                    ForEach(AnchorData.feelings) { feeling in
                        Button {
                            selected = feeling.id
                            showResult = false
                        } label: {
                            HStack {
                                Text(feeling.symbol)
                                Text(feeling.label).foregroundStyle(.primary)
                                Spacer()
                                if selected == feeling.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(.purple) }
                            }
                        }
                    }
                }
                Section("How intense is it? \(intensity)/10") {
                    Slider(value: Binding(get: { Double(intensity) }, set: { intensity = Int($0) }), in: 1...10, step: 1)
                    Button("Find my DBT skill") { showResult = true }.buttonStyle(.borderedProminent)
                }
                if showResult {
                    Section("A skill to try: \(recommendation.title)") {
                        Text(recommendation.reason)
                        ForEach(Array(recommendation.steps.enumerated()), id: \.offset) { index, step in
                            Label(step, systemImage: "\(index + 1).circle")
                        }
                    }
                }
            }.navigationTitle("How am I feeling?")
        }
    }
}

struct CrisisView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("🌊 Stop things from getting worse").font(.title.bold())
                Text("Our goal right now is to stop things from getting worse.").font(.headline).foregroundStyle(AnchorTheme.lavender)
                Text("You don't have to fix everything right now. You don't have to make the feeling disappear. You don't have to make any big decisions. Your only job right now is to get through this moment without doing anything that makes things harder for you. Pause. Breathe. Give yourself time. The emotion will change. The intensity will pass. Survive the moment. Don't make it worse. One moment at a time.")
                SoftCard {
                    Text("PAUSE. SURVIVE. REGULATE. THEN DECIDE.").font(.headline)
                    Text("Try one skill at a time. You can come back to the problem when you're calmer.")
                }
                NavigationLink(destination: SkillDetailView(title: "STOP", details: ["Stop. Don't act on the first urge.", "Take a step back.", "Observe your body, thoughts and urges.", "Proceed mindfully."])) { Label("Practise STOP", systemImage: "pause.circle") }
                NavigationLink(destination: SkillDetailView(title: "TIPP", details: ["Temperature: try a cool cloth on your face if safe; avoid extreme cold.", "Intense exercise: consider brief, safe movement if suitable for you.", "Paced breathing: gently lengthen your exhale.", "Paired muscle relaxation: tense and release muscle groups gently."])) { Label("Practise TIPP", systemImage: "wind") }
                NavigationLink(destination: SkillDetailView(title: "Grounding", details: ["Name five things you can see.", "Notice four things you can feel.", "Listen for three sounds.", "Notice two things you can smell and one you can taste."])) { Label("Grounding exercise", systemImage: "leaf") }
                Text("If you may act on an urge to harm yourself or someone else, cannot keep yourself safe, or are in immediate danger, contact emergency services now. In the UK call 999 or go to A&E. For urgent mental health help in England, NHS 111 can direct you to the mental health option. Samaritans: 116 123.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.padding()
        }.navigationTitle("Crisis Support")
    }
}

struct SkillsView: View {
    private let modules: [(String, [String])] = [
        ("Mindfulness", ["Wise Mind", "Observe, Describe, Participate", "One-mindfully", "Non-judgementally"]),
        ("Distress Tolerance", ["STOP", "TIPP", "ACCEPTS", "Self-soothing", "Pros and Cons", "Radical Acceptance", "IMPROVE"]),
        ("Emotion Regulation", ["Check the Facts", "Opposite Action", "PLEASE", "Build Mastery", "Cope Ahead"]),
        ("Interpersonal Effectiveness", ["DEAR MAN", "GIVE", "FAST", "Boundaries"])
    ]
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("The aim of distress tolerance is not to solve everything immediately. It's to get through the crisis without making it worse.")
                        .font(.subheadline).padding(.vertical, 6)
                }
                ForEach(modules, id: \.0) { module in
                    Section(module.0) {
                        ForEach(module.1, id: \.self) { skill in
                            NavigationLink(skill) {
                                SkillDetailView(title: skill, details: skillSteps(skill))
                            }
                        }
                    }
                }
            }.navigationTitle("DBT Skills")
        }
    }

    private func skillSteps(_ skill: String) -> [String] {
        switch skill {
        case "STOP": return ["Stop. Don't act on the first urge.", "Take a step back.", "Observe what is happening inside and around you.", "Proceed mindfully, guided by your goals."]
        case "TIPP": return ["Temperature: use a cool cloth on your face if safe; avoid extreme cold.", "Intense exercise: use brief, safe movement if suitable.", "Paced breathing: gently lengthen your exhale.", "Paired muscle relaxation: gently tense and release muscles."]
        case "ACCEPTS": return ["Activities: do something absorbing.", "Contributing: do a small kind act.", "Comparisons: remember a time you coped before.", "Emotions: use a safe activity to invite a different emotion.", "Push away: take a temporary mental break.", "Thoughts: count or use a puzzle.", "Sensations: use safe, soothing sensations."]
        case "Radical Acceptance": return ["Notice what reality is right now.", "Name the facts without approving or liking them.", "Notice the pain of fighting reality.", "Turn your mind toward acceptance again, as often as needed."]
        case "Check the Facts": return ["Describe the event without judgement.", "Notice your interpretations and assumptions.", "Ask what evidence supports or contradicts them.", "Choose an action that fits the facts."]
        case "Opposite Action": return ["Name the emotion and its action urge.", "Check whether the emotion fits the facts.", "If it doesn't, choose an action opposite to the urge.", "Repeat the opposite action until the emotion shifts."]
        case "DEAR MAN": return ["Describe the situation factually.", "Express your feelings and opinions.", "Assert what you want or say no.", "Reinforce the benefits.", "Stay mindful, appear confident, and negotiate."]
        default: return ["Notice what is happening without judging yourself.", "Choose one small, safe step.", "Practise the skill gently and adapt it with your therapist's guidance."]
        }
    }
}

struct SkillDetailView: View {
    let title: String
    let details: [String]
    var body: some View {
        List {
            Section {
                Text("Take this one step at a time. You don't need to do it perfectly.")
                    .foregroundStyle(.secondary)
            }
            Section("Try this") {
                ForEach(Array(details.enumerated()), id: \.offset) { index, item in
                    Label(item, systemImage: "\(index + 1).circle")
                }
            }
        }.navigationTitle(title)
    }
}

struct DailyCareView: View {
    @EnvironmentObject private var store: AnchorStore
    @State private var reminderTime = Calendar.current.date(from: DateComponents(hour: 9, minute: 0)) ?? .now
    @State private var reminderStatus = ""
    var body: some View {
        NavigationStack {
            List {
                Section("A gentle check-in") {
                    Toggle("💊 I've taken my medication", isOn: $store.medicationTaken)
                    Toggle("💧 I've had some water", isOn: $store.waterDone)
                    Toggle("🥪 I've eaten something", isOn: $store.foodDone)
                    Toggle("🧠 I've practised a DBT skill", isOn: $store.skillDone)
                    Toggle("🌿 I've done something kind for myself", isOn: $store.selfCareDone)
                }
                Section("Medication reminder") {
                    TextField("Medication name (optional)", text: $store.medicationName)
                    DatePicker("Daily reminder time", selection: $reminderTime, displayedComponents: .hourAndMinute)
                    Button("Save daily reminder") { Task { await saveMedicationReminder() } }
                    Button("Turn reminder off", role: .destructive) {
                        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["anchor.medication.daily"])
                        reminderStatus = "Daily reminder turned off."
                    }
                    if !reminderStatus.isEmpty {
                        Text(reminderStatus).font(.footnote).foregroundStyle(.secondary)
                    }
                    Text("This is a gentle reminder only. Follow your prescribed medication instructions; ANCHOR does not advise on doses.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Button("Reset daily check-in") { store.resetDailyCare() }
                    .foregroundStyle(.secondary)
            }.navigationTitle("Daily Care")
        }
    }

    @MainActor
    private func saveMedicationReminder() async {
        let center = UNUserNotificationCenter.current()
        do {
            let granted = try await center.requestAuthorization(options: [.alert, .sound, .badge])
            guard granted else {
                reminderStatus = "Notifications are off for ANCHOR. You can enable them in iPhone Settings."
                return
            }
            center.removePendingNotificationRequests(withIdentifiers: ["anchor.medication.daily"])
            let content = UNMutableNotificationContent()
            content.title = "A gentle ANCHOR reminder"
            content.body = "If medication is part of your care plan, check whether it is time."
            content.sound = .default
            let components = Calendar.current.dateComponents([.hour, .minute], from: reminderTime)
            let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
            let request = UNNotificationRequest(identifier: "anchor.medication.daily", content: content, trigger: trigger)
            try await center.add(request)
            reminderStatus = "Your daily reminder is set. You can change or turn it off here."
        } catch {
            reminderStatus = "The reminder could not be saved. Please check notification permissions in Settings."
        }
    }
}

struct ToolkitView: View {
    @EnvironmentObject private var store: AnchorStore
    var body: some View {
        NavigationStack {
            Form {
                Section("My early warning signs and triggers") {
                    TextEditor(text: $store.triggerNotes).frame(minHeight: 100)
                }
                Section("What helps me") {
                    TextEditor(text: $store.helpfulNotes).frame(minHeight: 100)
                }
                Section("Reasons and reminders that matter to me") {
                    TextEditor(text: $store.personalReasons).frame(minHeight: 100)
                }
                Section("Trusted contact") {
                    TextField("Name", text: $store.trustedContactName)
                    TextField("Phone number", text: $store.trustedContactPhone)
                        .keyboardType(.phonePad)
                }
                Text("Your entries are stored locally in this starter app. Add only information you are comfortable keeping on this device.")
                    .font(.footnote).foregroundStyle(.secondary)
            }.navigationTitle("My BPD Toolkit")
        }
    }
}
