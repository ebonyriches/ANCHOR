import SwiftUI
import UserNotifications

@main
struct AnchorApp: App {
    @StateObject private var store = AnchorStore.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .tint(AnchorTheme.lavender)
        }
    }
}
